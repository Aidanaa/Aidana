<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
<style type="text/css">

.center{
  display:block;
  margin:0 auto;
  width: 300px;
}

#menu {width:100%;padding: 0; width: 762px; margin: 0 auto;font-family: "Trebuchet MS", Helvetica, sans-serif;}
#menu ul {list-style: none; margin: 0; padding: 0}
#menu a {
float: left;
width: 125px;
text-decoration: none;
text-align: center;
padding: 0;
font-size: 20px;
color: white;
}
#menu a:hover { color: red;}
}
video {
    width: 100%;
    height: auto;

    }
   
#quote {
  font-weight:bold;
  font-family: "Times New Roman",Times,serif;
  font-size: 180%;
  color: #262626
}
#video{
  background-image: url("eminem12.jpg");
  margin-top: 30px;
  margin-left: 90px;
  width:96%;
}

.container{
      width:1318px;
      margin-left:20px;
}

 .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width: 60%;
      margin: auto;
  }

  #icons{
    margin-top:20px;
  }
  .biogr{
    margin-top: 20px;
    font-family: "Times New Roman", Times, serif;
    color:black;
  }

</style>
</head>
<body style="width:97%;margin-top:2px;background-color:black">

<!-- <div style="width:98%;margin-top:-10px;">
<div style="width:100%;height:120px;background-color:black;margin-top:5px;">
<img class="center" src="logo.png" 
<hr>
<div id="menu">
<ul>
<li><a href="Main.php?page=eminem">Home</a></li>
<li><a href="Main.php?page=lyrics">Lyrics</a></li>
<li><a href="lyrics.html">Photos</a></li>
<li><a href="lyrics.html">Contact us</a></li>


<li><a style="color:red;" href="Main.php?page=register">Register/Login</a></li>
</ul>
</div> -->
</div>

 <div style="margin-top:50px; margin-left:22px;">
<img style="width:1296px;" src="eminem11.jpg" alt="Eminem" width="95%";height="90%">
</div>

<!-- <div id="video">
<div style="width:800px;margin:auto;"> 
  
<video width="500px" controls=2>
  <source src="video.mp4" type="video/mp4">
</video>
</div>


</div>
 --> -->
<div style="width:100%;margin-left:40px;margin-top:10px;" align="center">
    <pre id="quote">"I am who I am and I say what I think. 
    I'm not putting a face on for the record."
    </pre>
</div>

<div class="container">
  <br>
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="eminem.jpg" style="border-width:0px; width:100%; height:100%;">
      </div>

      <div class="item">
        <img src="eminem2.jpg" style="border-width:0px; width:100%; height:100%;">
      </div>
    
      <div class="item">
        <img src="eminem3.jpg" style="border-width:0px; width:100%; height:100%;">
      </div>

      <div class="item">
        <img src="eminem4.jpg" style="border-width:0px; width:100%; height:100%;">
      </div>
      <div class="item">
        <img src="eminem5.jpg" style="border-width:0px; width:100%; height:100%;">
      </div>
      <div class="item">
        <img src="eminem6.jpg" style="border-width:0px; width:100%; height:100%;">
      </div>
      <div class="item">
        <img src="eminem7.jpg" style="border-width:0px; width:100%; height:100%;">
      </div>
      <div class="item">
        <img src="eminem8.jpg" style="border-width:0px; width:100%; height:100%;">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>

<div>
      <div  style="width: 50%; float: left;height:389px; margin-top:17px;">
      <p style="font-size:140%;color:white;margin-left:20px;margin-top:10px;">Eminem is an American rapper, record producer and actor known as one of the most controversial and best-selling artists of the early 21st century.<br>Born on October 17, 1972, in St. Joseph, Missouri, rap musician Eminem had a turbulent childhood. He released The Slim Shady LP in early 1999, and the album went multi-platinum, garnering Eminem two Grammy Awards and four MTV Video Music Awards. In 2000, the rapper released The Marshall Mathers LP, which was noted as the fastest-selling album in rap history. More recently, in 2010, Eminem released the Grammy-winning album Recovery, a highly autobiographical attempt to come to terms with his struggles with addiction and experience with rehabilitation. Eminem plans to release his eighth album, MMLP2, in 2013.</p>
      </div>
      <div style="width: 50%; float: left;margin-top:17px;"><div style="float: top;">
      <img src="relapse.jpg" style="width:250px;height:252px;margin-left:90px"></div>
      <div style="float:bottom;margin-left:90px;font-size:200%;font-family:Arial;">
      <p style="color:#8c8c8c;">Eminem/Relapse</p>
      </div>
      <div style="float:bottom;margin-top:17px;margin-left:90px;"><audio controls>
      <source src="Eminem-We made you.ogg" type="audio/ogg">
      <source src="Eminem-We made you.mp3" type="audio/mpeg">
      </audio>
      <div style="float:bottom;margin-top:10px;margin-left:0px;"><audio controls>
      <source src="Eminem-Lose yourself.ogg" type="audio/ogg">
      <source src="Eminem-Lose yourself.mp3" type="audio/mpeg">
      </audio>
      </div>
</div>



</div> 

</div>
</body>
</head>
</html>