<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css"> -->
<link rel="stylesheet" type="text/css" href="mycss.css">
</head>
<body>
<?php
include("project.php");
$page = $_REQUEST['page'];
 if($page == "eminem"){
 	include("Eminem.php");
 	?>
 	
    <?php
 }
 else if($page == "lyrics"){
 	include("lyrics.php");
	?>
	
	<?php
 }
 else if($page == "register"){
 	include("registration.php");
	?>
	<?php
 }
 else if($page == "post"){
 	include("post.php");
	?>

<?php
}
else{
	include("Eminem.php");
}
?>
</body>
</html> 