<html>
<head>
<style>
body{
	background-color:lightgray;

}
#header{
	width:100%;
	background:orange;
	height:200px;
	border-bottom: 5px solid blue;
}
#sidebar{
	width:250px;
	float:left;
	background:orange;
	border-right:5px solid blue;
	height:600px;

}

#header h1{
	color:black;
	font-size:3em;
	font-family:comic sans MS;
	text-align: center;
	padding: 20px;
}
</style>
</head>
<body>
<div id="header">
	<h1>Welcome to the Admin panel</h1>
</div>
<div id="sidebar">
<p>Sidebar</p>
</div>
</body>
</html>
