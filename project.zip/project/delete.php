
<?php
include("conn.php");
if(isset($_GET['del'])){
	$delete_id=$_GET['del'];
	$delete_query="delete from eminem where id=$delete_id ";
if(mysql_query($delete_query)){
	echo "<script>alert('Post has been deleted')</script>";
	echo "<script>window.open('view.php','_self')</script>";
}
}


?>