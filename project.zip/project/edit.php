<html>
<head>
<style>
body{
	background-color:gray;
	padding:0;
	margin:0;


}
#header{
	width:100%;
	background:orange;
	height:200px;
	border-bottom: 5px solid blue;
}
#sidebar{
	width:250px;
	float:left;
	background:orange;
	border-right:5px solid blue;
	height:600px;

}

#header h1{
	color:black;
	font-size:3em;
	font-family:comic sans MS;
	text-align: center;
	padding: 20px;
}
#sidebar h2{
	text-align:center;
	font-size:2em;
	color:brown; 
}

</style>
</head>
</head>
<body>
<div id="header">
<a href="index.php">
	<h1>Welcome to the Admin panel</h1>
</a>	
</div>
<div id="sidebar">

<h2><a href="#">Logout</a>
<h2><a href="view.php">View posts</a>
<h2><a href="#">Insert new post</a>
<h2><a href="#">View comments</a>
</div>
<?php
include("conn.php");
if(isset($_GET['edit'])){
	$edit_id=$_GET['edit'];
	$edit_query="select * from eminem where id='$edit_id'";
	$run_edit=mysql_query($edit_query);
	while($edit_row=mysql_fetch_array($run_edit)){
		$id=$edit_row['id'];
		$title=$edit_row['title'];
		$author=$edit_row['author'];
		$keywords=$edit_row['keywords'];
		$image=$edit_row['image'];
		$content=$edit_row['content'];



}
}
?>



<form method="post" action="edit.php?edit_form=<?php echo $edit_id; ?>" enctype="multipart/form-data">
<table width="600" align="center" border="10" bgcolor="orange">
	<tr>
	<td align="center" bgcolor="yellow" colspan="6"><h1>Edit the post here</h1></td>
	</tr>
	<tr>
	<td align="right">Post Title:</td>
	<td><input type="text" name="title" size="30" value="<?php echo $title;?>"></td>
	</tr>
<tr>
	<td align="right">Post Author:</td>
	<td><input type="text" name="author" size="30" value="<?php echo $author;?>"></td>
</tr>
<tr>
	<td align="right">Post Keywords:</td>
	<td><input type="text" name="keywords" size="30" value="<?php echo $keywords; ?>"></td>
</tr>
<tr>
	<td align="right">Post Image:</td>
	<input type="file" name="image">
	<td><img src="../images/<?php echo $image; ?>" width="100" height="100"></td>
</tr>
<tr>
	<td align="right">Post Content:</td>
	<td><textarea name="content" cols="40" rows="20"><?php echo $content;?></textarea></td>
</tr>
<tr>
	<td align="center" colspan="6"><input type="submit" name="update" value="Update now"</td>
</tr>

</table>
</form>

</body>
</html>
<?php
	
	if(isset($_POST['update'])){
	
	$update_id = $_GET['edit_form'];
	$title1 = $_POST['title'];
	  $date1 = date('m-d-y');
	  $author1 = $_POST['author'];
	  $keywords1 = $_POST['keywords'];
	  $content1 = $_POST['content'];
	  $image1= $_FILES['image']['name'];
	  $image_tmp= $_FILES['image']['tmp_name'];

if($title1=='' or $author1=='' or $keywords1=='' or $content1=='' or $image1==''){
	
	echo "<script>alert('Any of the fields is empty')</script>";
	exit();
	}
else {
	
	 move_uploaded_file($image_tmp,"$image1");
		
		$update_query = "update eminem set title='$title1',author='$author1',image='$image1',keywords='$keywords1',content='$content1' where id='$update_id'";
		
		if(mysql_query($update_query)){
		
		echo "<script>alert('Post has been updated')</script>";
		
		echo "<script>window.open('view.php','_self')</script>";
		
		}
	
	}
	}



?>