<?php 
session_start();

if(!isset($_SESSION['user_name'])){

header("location: login.php");
}
else {
?>
<html>
<head>
<style>
body{
	background-color:gray;
	padding:0;
	margin:0;


}
#header{
	width:100%;
	background:pink;
	height:200px;
	border-bottom: 5px solid blue;
}
#sidebar{
	width:250px;
	float:left;
	background:pink;
	border-right:5px solid blue;
	height:600px;

}

#header h1{
	color:black;
	font-size:3em;
	font-family:comic sans MS;
	text-align: center;
	padding: 20px;
}
#sidebar h2{
	text-align:center;
	font-size:2em;
	color:brown; 
}

</style>
</head>
<body>
<div id="header">
<a href="index.php">
	<h1>Welcome to the Admin panel</h1>
</a>	
</div>
<div id="sidebar">

<h2><a href="logout.php">Logout</a>
<h2><a href="view.php">View posts</a>
<h2><a href="index.php?insert=insert">Insert new post</a>

</div>

<?php
if(isset($_GET['insert'])){
	include("new.php");
}
?>


</body>

</html>
<?php }?>
