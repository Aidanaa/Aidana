<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">

<style>
	body{
		background-image: url('bck.jpg');
	}
</style>

<body style="background-color:black;">



<!-- <p><span class="error">* required field.</span></p> -->
<form method='post' action='login1.php'>

<table width="400" border="5" align="center">
<tr>
	<td align-"center" colspan='5'><h1>Login form</h1></td>
</tr>
<tr>
	<td align='center'>Password</td>
	<td><input type='password' name='pass' /></td>
</tr>
<tr>
	<td align='center'>Email</td>
	<td><input type='text' name='email' /></td>
</tr>
<tr>
	
	<td colspan='5' align='center'><input type='submit' name='login' value='Login' /></td>
</tr>
</table>
</form>

<font color="red" size="8">Not registered yet?</font><a href="registration.php">Sign up here</a>

</body>
</head>
</html>



<?php
include("conn.php");
 if(isset($_POST['login'])){
  
 	$password=$_POST['pass'];
 	$email=$_POST['email'];
// if (empty($_POST["email"])) {
//     $emailErr = "Email is required";
//   } else {
//     $email = test_input($_POST["email"]);
//     // check if e-mail address is well-formed
//     if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
//       $emailErr = "Invalid email format"; 
//     }
//   }
//   function test_input($data) {
//   $data = trim($data);
//   $data = stripslashes($data);
//   $data = htmlspecialchars($data);
//   return $data;
// }
    

$check_user="select * from users where user_pass='$password' AND user_email='$email'";


$run=mysql_query($check_user);
if(mysql_num_rows($run)>0){
	echo "<script>window.open('Main.php','_self')</script>";
}
else{
	echo "<script>alert('Email or password is incorrect!')</script>";
}





}
?>
