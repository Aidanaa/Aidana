<html>
<head>
<style>
	.center{
  display:block;
  margin:0 auto;
  width: 300px;
}

#menu {width:100%;padding: 0; width: 762px; margin-left:340px;font-family: "Trebuchet MS", Helvetica, sans-serif;}
#menu ul {list-style: none; margin: 0; padding: 0}
#menu a {
float: left;
width: 125px;
text-decoration: none;
text-align: center;
padding: 0;
font-size: 20px;
color: white;
}
#menu a:hover { color: red;}
}
</style>
<body style="background-color:black;">
 <div style="width:100%;height:120px;background-color:black;margin-top:5px;">
<img class="center" src="logo.png" 
<hr>
<div id="menu">
<ul>
<li><a href="Eminem.html">Home</a></li>
<li><a href="facts.html">50 Facts</a></li>
<li><a href="lyrics.html">Lyrics</a></li>
<li><a style="color:red;" href="register.html">Register/Login</a></li>
</ul>
</div>
</div>
<div style="width:50%;position:fixed;">
<img src="lyric.gif">
<div>
	<div style="float:bottom;margin-top:40px;margin-left:90px;"><audio controls>
	      <source src="Lose yourself.ogg" type="audio/ogg">
	      <source src="Lose yourself.mp3" type="audio/mpeg">
	      </audio>
	</div>
</div>	
</div>
<div style="width:50%;float:right;margin-top:-15px;">
<pre style="color:white;font-family:Comic Sans MS">
<h3>Lose yourself</h3>
Look, if you had, one shot, or one opportunity
To seize everything you ever wanted. In one moment
Would you capture it, or just let it slip?
Yo
His palms are sweaty, knees weak, arms are heavy
There's vomit on his sweater already, mom's spaghetti
He's nervous, but on the surface he looks calm and ready to drop bombs,
But he keeps on forgetting what he wrote down,
The whole crowd goes so loud
He opens his mouth, but the words won't come out
He's choking how, everybody's joking now
The clock's run out, time's up, over, blaow!
Snap back to reality. Oh, there goes gravity
Oh, there goes Rabbit, he choked
He's so mad, but he won't give up that
Easy, no
He won't have it, he knows his whole back's to these ropes
It don't matter, he's dope
He knows that but he's broke
He's so sad that he knows
When he goes back to his mobile home, that's when it's
Back to the lab again, yo
This whole rhapsody
He better go capture this moment and hope it don't pass him

[Hook:]
You better lose yourself in the music, the moment
You own it, you better never let it go (go)
You only get one shot, do not miss your chance to blow
This opportunity comes once in a lifetime (yo)
You better lose yourself in the music, the moment
You own it, you better never let it go (go)
You only get one shot, do not miss your chance to blow
This opportunity comes once in a lifetime (yo)
(You better)

The soul's escaping, through this hole that is gaping
This world is mine for the taking
Make me king, as we move toward a new world order
A normal life is boring, but superstardom's close to postmortem
It only grows harder, homie grows hotter
He blows. It's all over. These hoes is all on him
Coast to coast shows, he's known as the globetrotter
Lonely roads, God only knows
He's grown farther from home, he's no father
He goes home and barely knows his own daughter
But hold your nose 'cause here goes the cold water
His hoes don't want him no more, he's cold product
They moved on to the next schmoe who flows
He nose dove and sold nada
So the soap opera is told and unfolds
I suppose it's old partner, but the beat goes on
Da da dum da dum da da da da

[Hook]

No more games, I'm a change what you call rage
Tear this motherfucking roof off like two dogs caged
I was playing in the beginning, the mood all changed
I've been chewed up and spit out and booed off stage
But I kept rhyming and stepped right into the next cypher
Best believe somebody's paying the Pied Piper
All the pain inside amplified by the
Fact that I can't get by with my 9 to 5
And I can't provide the right type of life for my family
'Cause man, these goddamn food stamps don't buy diapers
And it's no movie, there's no Mekhi Phifer, this is my life
And these times are so hard, and it's getting even harder
Trying to feed and water my seed, plus
Teeter totter caught up between being a father and a primadonna
Baby, mama drama's screaming on her
Too much for me to wanna
Stay in one spot, another day of monotony's gotten me
To the point, I'm like a snail
I've got to formulate a plot or I end up in jail or shot
Success is my only motherfucking option, failure's not
Mom, I love you, but this trailer's got to go
I cannot grow old in Salem's lot
So here I go it's my shot.
Feet, fail me not
This may be the only opportunity that I got
</pre>
</div>

</div>

</body>
</head>
</html>