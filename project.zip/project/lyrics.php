<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
.center{
  display:block;
  margin:0 auto;
  width: 300px;
}

#menu {width:100%;padding: 0; width: 762px; margin-left:340px;font-family: "Trebuchet MS", Helvetica, sans-serif;}
#menu ul {list-style: none; margin: 0; padding: 0}
#menu a {
float: left;
width: 125px;
text-decoration: none;
text-align: center;
padding: 0;
font-size: 20px;
color: white;
}
#menu a:hover { color: red;}
}
#trailer {
	position: fixed;
	top: 0; right: 0; bottom: 0; left: 0;
	overflow: hidden;
}

#trailer > video {
	position: relative;
	top:0px;
	left: 80px;
	width: 100%;
	height: 100%;

}
.list_songs{
	position:fixed;
    
}
.active{
       color:white;
       font-size:20px;
}
a{
	text-decoration: none;
	color:white;
	font-size:20px;
	font-family: Arial, Helvetica, sans-serif;
}
</style>
<body style="background-color:black;">
 <div style="margin-left:850px;margin-top:-80px;">
<form action=""> 
 <input type="text" id="txt1" onkeyup="showHint(this.value)">
</form>
</div>
 
<p style="margin-left:1000px;;font-size:20px;color:white;">Suggestions: <span id="txtHint"></span></p> 
<script>
function showHint(str) {
  var xhttp;
  if (str.length == 0) { 
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("txtHint").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "gethint.php?q="+str, true);
  xhttp.send();   
}
</script>

 <div style="margin-top:5px;">


 <!-- <div style="width:100%;height:120px;background-color:black;margin-top:-10px;">
<img class="center" src="logo.png" 
<hr>
<div id="menu">
<ul>
<li><a href="Main.php?page=eminem">Home</a></li>
<li><a href="Main.php?page=lyrics">Lyrics</a></li>
<li><a href="lyrics.html">Photos</a></li>
<li><a href="lyrics.html">Contact us</a></li>

<li><a style="color:red;" href="register.html">Register/Login</a></li>
</ul>
</div>  -->
</div>
<div id="trailer" class="is_overlay">
	<video  id="video" width="1362px;" height="auto" autoplay="autoplay" loop="loop" preload="auto" muted="muted" controls="controls">
		<source src="lyric.mp4"></source>
		<source src="lyric.webm" type="video/webm"></source>
	</video>
<div style="position:absolute; margin-left:-60px;margin-top:-740px;">
<h1>
<ul>
        <div class="list_songs"></div>
     </li>
       <ul style="list-style-type:none">
                                               
									            <li><a style="color:red;" href="Eminem.html">Home</a></li>
									            <li><a href="beautiful.html">Beautiful</a></li>
									            <li><a href="berzerk.html">Berzerk</a></li>
                                                <li><a href="cleanin_out_my_closet.html">Cleanin' Out My Closet</a></li>                                                                                                                            <li><a href="hailie_s_song.html">Hailie's Song</a></li>
                                                <li><a href="headlights.html">Headlights</a></li>      
                                               
                                                <li><a href="lose yourself.html">Lose Yourself*</a></li>
                                             </li>    
                                                <li><a href="love_the_way_you_lie.html">Love the Way You Lie</a></li>
                                        
                                                <li><a href="not_afraid.html">Not Afraid</a></li>
                                                <li><a href="phenomenal.html">Phenomenal</a></li>
                                                <li><a href="rap_god.html">Rap God</a></li>
                                                <li><a href="sing_for_the_moment.html">Sing For the Moment</a></li>
                                                <li><a href="stan.html">Stan</a></li>
                                               
                                                <li><a href="survival.html">Survival</a></li> 
                                                <li><a href="the_real_slim_shady.html">The Real Slim Shady</a></li> 
                                                <li><a href="the_way_i_am.html">The Way I Am</a></li>
                                                <li><a href="till_i_collapse.html">Till I Collapse</a></li> 
                                                <li><a href="we_made_you.html">We Made You</a></li>
                                                <li><a href="when_i_m_gone.html">When I'm Gone</a></li>
                                                <li><a href="white_america.html">White America</a></li>
                                              
                                                                               
                                                                                           
                                               
                     
      </ul>
<br> 
</div>
</div>    
</div>                                          
                                                                            
                                                
</body>
</head>
</html>
          


