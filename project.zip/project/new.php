<html>
<head>
<body>
<form method="post" action="new.php" enctype="multipart/form-data">
<table width="600" align="center" border="10">
	<tr>
	<td align="center" bgcolor="yellow" colspan="6"><h1>Insert new post here</h1></td>
	</tr>
	<tr>
	<td align="right">Post Title:</td>
	<td><input type="text" name="title"></td>
	</tr>
<tr>
	<td align="right">Post Author:</td>
	<td><input type="text" name="author"></td>
</tr>
<tr>
	<td align="right">Post Keywords:</td>
	<td><input type="text" name="keywords"></td>
</tr>
<tr>
	<td align="right">Post Image:</td>
	<td><input type="file" name="image"></td>
</tr>
<tr>
	<td align="right">Post Content:</td>
	<td><textarea name="content" cols="40" rows="20"></textarea></td>
</tr>
<tr>
	<td align="center" colspan="6"><input type="submit" name="submit" value="Publish now"</td>
</tr>
</table>
</form>
</body>
</head>
</html>
<?php
include("conn.php");
if(isset($_POST['submit'])){
	 $title=$_POST['title'];
	 $author=$_POST['author'];
	 $date=date('d-m-y');
	 $image=$_FILES['image']['name'];
	 $keywords=$_POST['keywords'];
	 $content=$_POST['content'];
	 $image_tmp=$_FILES['image']['tmp_name'];

if($title=='' or $keywords=='' or $content=='' or $author==''){
	echo "<script>alert(' Any of the fields is empty')</script>";
	exit();
}
else{
	move_uploaded_file($image_tmp, "$image");
	$insert_query="insert into eminem(title,date,author,image,keywords,content) values('$title','$date','$author','$image','$keywords','$content') ";

if (mysql_query($insert_query)){
	echo "<script>alert('post published successfully')</script>";
echo "<script>window/open('view.php','_self')</script>";
}
}


	}


?>
