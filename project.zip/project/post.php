<html>
<head>
<style>
	#searchbox{
		margin-top:10px;
		text-align: center;

	}
</style>
<body style="width:70%;margin-left:180px;background-color:lightgrey;border-style:double;border-width:5px;">
<div id ="searchbox">
<form action="search.php" method="get" enctype="multipart/form-data">
<input type="text" name="value" placeholder="Search" size="25">
<input type="submit" name="search" value="Search">
</form>
</div>
<h3	><a href="index.php">Admin</a></h3>

 	<?php
 	include("conn.php");
$select_post="select * from eminem order by rand() LIMIT 0,4";
$run_posts=mysql_query($select_post);
while($row=mysql_fetch_array($run_posts)){
	$id=$row['id'];
	$title=$row['title'];
	$author=$row['author'];
	$date=$row['date'];
	$image=$row['image'];
	$keywords=$row['keywords'];
	$content=$row['content'];
	




 	?>
 	<h2><?php echo $title; ?></h2>
 	<p align="left">Published on:<b><?php echo $date; ?></p>
 	<p align="right">Posted by:<b><?php echo $author; ?></b>
 	<p align="justify"><?php echo $content; ?></p>
 	<center><img src="<?php echo $image; ?>" width="500" height="400"></center>
 	<?php } ?>

</body>
</head>
</html>
