<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<style type="text/css">
.center{
    display:block;
    margin:0 auto;
    width: 300px;
}
#menu {width:100%;padding: 0; width: 762px; margin: 0 auto;margin-bottom:30px;font-family: "Trebuchet MS", Helvetica, sans-serif}
#menu ul {list-style: none;padding:0px;}
#menu a {
float: left;
width: 125px;
text-decoration: none;
text-align: center;
padding: 0;
font-size: 20px;
color: white;
}
#menu a:hover { color: red;}
}
.women{
    position: relative;
    width: 100%;
  }
</style>

</head>
<body>
<div style="width:100%;height:120px;background-color:black;">
<img class="center" src="logo.png" 
<hr>
<div id="menu">
<ul>
<li><a href="Main.php?page=eminem">Home</a></li>
<li><a href="Main.php?page=lyrics">Lyrics</a></li>
<li><a href="Main.php?page=post">News</a></li>
<li><a href="lyrics.html">Contact us</a></li>

<li><a style="color:red;" href="Main.php?page=register">Register/Login</a></li>
</ul>
</div>
</div>  
</body>
</html>