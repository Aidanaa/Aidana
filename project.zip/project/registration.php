<html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/j.."></script> 
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/boo.."></script>
<head>
<style>
	body{
		background-image: url('bck.jpg');
	}
</style>
<script> 
function validation() { 
var x = document.forms["form"]["name"].value; 
 
var y = document.forms["form"]["pass"].value; 
 
var b = document.forms["form"]["email"].value; 
if (x == null || x == "") { 
alert("Name must be filled out"); 
return false;} 
if (y == null || y == "") { 
alert("Password must be filled out"); 
return false;} 
if (b == null || b == "") { 
alert("E mail must be filled out"); 
return false;} 
} 
</script>
</head>
<body>
<form method='post' action='registration.php' name='form' onsubmit="return validation()">

<table width="400" border="5" align="center">
<tr>
	<td colspan='5'><h1>Registration form</h1></td>
</tr>
<tr>
	<td align='center'>User name</td>
	<td><input type='text' name='name' /></td>
</tr>
<tr>
	<td align='center'> User password</td>
	<td><input type='password' name='pass' /></td>
</tr>
<tr>
	<td align='center'>Email</td>
	<td><input type='text' name='email' /></td>
</tr>
<tr>
	
	<td colspan='5' align='center'><input type='submit' name='submit' value='Sign up' /></td>
</tr>
</table>
</form>
<center><b>Already registered</b><a href='login1.php'><br>Login here</br></a></center>
</body>
</html>
<?php
include("conn.php");
if(isset($_POST['submit'])){
	echo $user_name=$_POST['name'];
	$user_pass=$_POST['pass'];
	$user_email=$_POST['email'];


// if($user_name==''){
// 	echo "<script>alert('Please enter your name!')</script>";
// exit();
// }
// if($user_pass==''){
// 	echo "<script>alert('Please enter your password!')</script>";
// exit();
// }
// if($user_email==''){
// 	echo "<script>alert('Please enter your email!')</script>";
// exit();
// }
$check_email="select * from users where user_email='$user_email' ";

$run=mysql_query($check_email);
if(mysql_num_rows($run)>0){
	echo "<script>alert('Email $user_email is already exist in our database, please another one!')</script>";
exit();
}
$query="insert into users (user_name,user_pass,user_email) values ('$user_name','$user_pass','$user_email')";
if (mysql_query($query)){
	echo "<script>window.open('Main.php','_self')</script>";
}




}
?>
