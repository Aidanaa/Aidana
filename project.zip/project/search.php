<html>
<head>
<body style="width:70%;margin-left:180px;background-color:lightgrey;border-style:double;border-width:5px;">
<h3><a href="index.php">Admin</a></h3>
<div><?php include("post.php"); ?></div>
<?php
 include("conn.php");

if (isset($_GET['search'])){
	  $search_id=$_GET['value'];
	
	$search_query="select * from eminem where keywords like '%$search_id%'";
	$run_query=mysql_query($search_query);
	while($search_row=mysql_fetch_array($run_query)){
		$title=$search_row['title'];
		$image=$search_row['image'];
		$content=substr($search_row['content'],0,150);
	
	}
	?>
	<center>
	<h1>Your search result is here</h1>

	<h2><?php echo $title; ?></h2>

	<img src="<?php echo $image;?>">

	<p><?php echo $content; ?></p>
	</center>
	<?php } ?>
	
	 
</body>
</head>
</html>



