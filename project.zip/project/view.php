<?php 
session_start();

if(!isset($_SESSION['user_name'])){

header("location: login.php");
}
else {

?>

<html>
<head>
	<title>Admin Panel</title>
	
	<style>
	body{
	background-color:gray;
	padding:0;
	margin:0;


}
#header{
	width:100%;
	background:pink;
	height:200px;
	border-bottom: 5px solid blue;
}
#sidebar{
	width:250px;
	float:left;
	background:pink;
	border-right:5px solid blue;
	height:600px;

}

#header h1{
	color:black;
	font-size:3em;
	font-family:comic sans MS;
	text-align: center;
	padding: 20px;
}
#sidebar h2{
	text-align:center;
	font-size:2em;
	color:brown; 
}

	</style>
	</head>
	
<body>
<div id="header">
<a href="index.php">
<h1>Welcome to the Admin Panel</h1></a>

</div> 

<div id="sidebar">
<h2><a href="#">Logout</a></h2>
<h2><a href="view.php">View Posts</a></h2>
<h2><a href="index.php?insert=insert">Insert New Post</a></h2>

</div>
</head>
<body>
<table width="1000" border="5" align="center" bgcolor="pink">
<tr>
	<td colspan="10" align="center" bgcolor="pink"><h1>View all posts</h1></td>
</tr>

<tr bgcolor="purple">
	<th>Post No:</th>
	<th>Post Date:</th>
	<th>Post Author:</th>
	<th>Post Title:</th>
	<th>Post Image:</th>
	<th>Post Content:</th>
	<th>Delete Post:</th>
	<th>Edit No:</th>
</tr>

<?php
include("conn.php");
$query="select * from eminem";
$run=mysql_query($query);
while($row=mysql_fetch_array($run)){
	$id=$row['id'];
	$title=$row['title'];
	$author=$row['author'];
	$date=$row['date'];
	$image=$row['image'];
	$content=substr($row['content'],0,100);

?>
<tr slign="center">
	<td><?php echo $id; ?></td>
	<td><?php echo $date; ?></td>
	<td><?php echo $author; ?></td>
	<td><?php echo $title; ?></td>
	<td><img src="<?php echo $image; ?>" width="80" height="80"></td>
	<td><?php echo $content; ?></td>
	<td><a href="delete.php?del=<?php echo $id;?>">Delete</a></td>
	<td><a href="edit.php?edit=<?php echo $id;?>">Edit</a></td>
</tr>
<?php } ?>

</table>
</body>
</html>
<?php } ?>
